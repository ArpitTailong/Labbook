package com.cg.trainee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraineeLabbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraineeLabbookApplication.class, args);
	}

}
