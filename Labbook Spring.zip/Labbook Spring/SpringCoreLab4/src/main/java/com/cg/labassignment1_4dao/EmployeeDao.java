package com.cg.labassignment1_4dao;

import com.cg.labassignment1_4entities.Employee;

public interface EmployeeDao {
	Employee retrieveEmployeeInformation(int employeeId);

}
