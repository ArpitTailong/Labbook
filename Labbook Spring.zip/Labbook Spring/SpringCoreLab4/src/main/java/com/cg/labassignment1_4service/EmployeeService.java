package com.cg.labassignment1_4service;

import com.cg.labassignment1_4entities.Employee;

public interface EmployeeService {
	Employee retrieveEmployeeInformation(int employeeId);
}
