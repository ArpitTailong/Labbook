package com.cg.ma.exception;

public class MovieException extends Exception {

	private static final long serialVersionUID = 1L;
	/* UserDefined Exception for Bill*/
	public MovieException(String errorMessege) {
		super(errorMessege);
	}
}
	

